<?php
class StudentManager {
    public $Id;
    public $Name;
    public $Lastname;

    private $conn;

    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }

    public function addStudent($data) {
        $lastName = $this->Lastname;
        $firstName = $data['firstName'];
        $middleName = $data['middleName'];
        $birthDate = $data['birthDate'];
        $gender = $data['gender'];
        $contactNumber = $data['contactNumber'];
        $educationLevel = $data['educationLevel'];
        $department = $data['department'];
        $groupName = $data['groupName'];
        $fundingType = $data['fundingType'];
        $admissionYear = $data['admissionYear'];
        $graduationYear = $data['graduationYear'];
        $dismissalInfo = !empty($data['dismissalInfo']) ? "'{$data['dismissalInfo']}'" : 'NULL';
        $dismissalDate = !empty($data['dismissalDate']) ? "'{$data['dismissalDate']}'" : 'NULL';
        $notes = $data['notes'];
        $parentsInfo = $data['parentsInfo'];
        $penalties = $data['penalties'];

        $query = "INSERT INTO Students (LastName, FirstName, MiddleName, BirthDate, Gender, ContactNumber, EducationLevel, Department, GroupName, FundingType, AdmissionYear, GraduationYear, DismissalInfo, DismissalDate, Notes, ParentsInfo, Penalties)
                  VALUES ('$lastName', '$firstName', '$middleName', '$birthDate', '$gender', '$contactNumber', '$educationLevel', '$department', '$groupName', '$fundingType', '$admissionYear', '$graduationYear', $dismissalInfo, $dismissalDate, '$notes', '$parentsInfo', '$penalties')";
        return $this->conn->query($query);
    }

    public function editStudent($data) {
        $studentID = $data['studentID'];
        $lastName = $data['lastName'];
        $firstName = $data['firstName'];
        $middleName = $data['middleName'];
        $birthDate = $data['birthDate'];
        $gender = $data['gender'];
        $contactNumber = $data['contactNumber'];
        $educationLevel = $data['educationLevel'];
        $department = $data['department'];
        $groupName = $data['groupName'];
        $fundingType = $data['fundingType'];
        $admissionYear = $data['admissionYear'];
        $graduationYear = $data['graduationYear'];
        $dismissalInfo = !empty($data['dismissalInfo']) ? "'{$data['dismissalInfo']}'" : 'NULL';
        $dismissalDate = !empty($data['dismissalDate']) ? "'{$data['dismissalDate']}'" : 'NULL';
        $notes = $data['notes'];
        $parentsInfo = $data['parentsInfo'];
        $penalties = $data['penalties'];

        $query = "UPDATE Students SET
                  LastName = '$lastName',
                  FirstName = '$firstName',
                  MiddleName = '$middleName',
                  BirthDate = '$birthDate',
                  Gender = '$gender',
                  ContactNumber = '$contactNumber',
                  EducationLevel = '$educationLevel',
                  Department = '$department',
                  GroupName = '$groupName',
                  FundingType = '$fundingType',
                  AdmissionYear = '$admissionYear',
                  GraduationYear = '$graduationYear',
                  DismissalInfo = $dismissalInfo,
                  DismissalDate = $dismissalDate,
                  Notes = '$notes',
                  ParentsInfo = '$parentsInfo',
                  Penalties = '$penalties'
                  WHERE StudentID = '$studentID'";
        return $this->conn->query($query);
    }

    public function deleteStudent($studentID) {
        // Начинаем транзакцию
        $this->conn->begin_transaction();

        try {
            // Удаляем связанные записи из таблицы DisabledStudents
            $query = "DELETE FROM DisabledStudents WHERE StudentID = '$studentID'";
            $this->conn->query($query);

            // Удаляем связанные записи из таблицы Orphans
            $query = "DELETE FROM Orphans WHERE StudentID = '$studentID'";
            $this->conn->query($query);

            // Удаляем связанные записи из таблицы SpecialNeedsStudents
            $query = "DELETE FROM SpecialNeedsStudents WHERE StudentID = '$studentID'";
            $this->conn->query($query);

            // Удаляем связанные записи из таблицы Dormitories
            $query = "DELETE FROM Dormitories WHERE StudentID = '$studentID'";
            $this->conn->query($query);

            // Удаляем связанные записи из таблицы RiskGroups
            $query = "DELETE FROM RiskGroups WHERE StudentID = '$studentID'";
            $this->conn->query($query);

            // Удаляем связанные записи из таблицы SPPPMeetings
            $query = "DELETE FROM SPPPMeetings WHERE StudentID = '$studentID'";
            $this->conn->query($query);

            // Удаляем связанные записи из таблицы SVOStatus
            $query = "DELETE FROM SVOStatus WHERE StudentID = '$studentID'";
            $this->conn->query($query);

            // Удаляем связанные записи из таблицы SocialScholarships
            $query = "DELETE FROM SocialScholarships WHERE StudentID = '$studentID'";
            $this->conn->query($query);

            // Удаляем запись из таблицы Students
            $query = "DELETE FROM Students WHERE StudentID = '$studentID'";
            $this->conn->query($query);

            // Подтверждаем транзакцию
            $this->conn->commit();
        } catch (Exception $e) {
            // Откатываем транзакцию в случае ошибки
            $this->conn->rollback();
            throw $e;
        }
    }

    public static function get() {
        global $conn;

        $students = array();
        # получать данные
        $query = "SELECT * FROM Students WHERE 1=1";
        $result = $conn->query($query);
        while($row = $result->fetch_assoc()) {
            array_push($students, $row);
        }
        return $students;
    }
}
?>