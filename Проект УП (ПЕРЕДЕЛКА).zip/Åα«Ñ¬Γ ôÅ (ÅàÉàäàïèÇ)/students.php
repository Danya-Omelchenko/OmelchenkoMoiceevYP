<?php
session_start();
include 'db_connection.php'; // Подключение к базе данных
include 'models/StudentManager.php'; // Подключение класса управления студентами

$studentManager = new StudentManager($conn);

// Обработка добавления студента
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_student'])) {
    $student = new Student($_POST);
    $studentManager->addStudent($student);
}

// Обработка редактирования студента
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_student'])) {
    $student = new Student($_POST);
    $studentManager->editStudent($student);
}

// Обработка удаления студента
if (isset($_GET['delete_id'])) {
    $studentManager->deleteStudent($_GET['delete_id']);
}

// Получение списка студентов
$students = $studentManager->getStudents();

// Отладочный вывод
echo "<pre>";
print_r($students);
echo "</pre>";
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Список студентов</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo-title">
                <img src="img/logo.png" alt="Логотип">
                <h1>Список студентов</h1>
            </div>
            <div class="login-button">
                <?php if (isset($_SESSION['username'])): ?>
                    <a href="logout.php" class="button button-red">Выйти</a>
                <?php else: ?>
                    <a href="login.php" class="button button-red">Войти</a>
                <?php endif; ?>
            </div>
        </div>
    </header>
    <nav>
        <ul>
            <li><a href="index.php">Главная</a></li>
            <li><a href="students.php">Студенты</a></li>
            <li><a href="orphans.php">Сироты</a></li>
            <li><a href="disabled.php">Инвалиды</a></li>
            <li><a href="special_needs.php">ОВЗ</a></li>
            <li><a href="dormitories.php">Общежитие</a></li>
            <li><a href="risk_groups.php">Группа риска</a></li>
            <li><a href="sppp_meetings.php">СППП</a></li>
            <li><a href="svo_status.php">СВО</a></li>
            <li><a href="social_scholarships.php">Социальная стипендия</a></li>
        </ul>
    </nav>
    <main>
        <section>
            <h2>Список студентов</h2>
            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                <button onclick="showAddForm()" class="button button-blue">Добавить студента</button>
            <?php endif; ?>

            <!-- Форма для добавления студента -->
            <div id="addForm" style="display: none;">
                <h3>Добавить студента</h3>
                <form method="post" action="students.php">
                    <input type="hidden" name="add_student" value="1">
                    <label for="lastName">Фамилия:</label>
                    <input type="text" id="lastName" name="lastName" required>

                    <label for="firstName">Имя:</label>
                    <input type="text" id="firstName" name="firstName" required>

                    <label for="middleName">Отчество:</label>
                    <input type="text" id="middleName" name="middleName" required>

                    <label for="birthDate">Дата рождения:</label>
                    <input type="date" id="birthDate" name="birthDate" required>

                    <label for="gender">Пол:</label>
                    <input type="text" id="gender" name="gender" required>

                    <label for="contactNumber">Контактный номер:</label>
                    <input type="text" id="contactNumber" name="contactNumber" required>

                    <label for="educationLevel">Образование:</label>
                    <input type="text" id="educationLevel" name="educationLevel" required>

                    <label for="department">Отделение:</label>
                    <input type="text" id="department" name="department" required>

                    <label for="groupName">Группа:</label>
                    <input type="text" id="groupName" name="groupName" required>

                    <label for="fundingType">Финансирование:</label>
                    <input type="text" id="fundingType" name="fundingType" required>

                    <label for="admissionYear">Год поступления:</label>
                    <input type="text" id="admissionYear" name="admissionYear" required>

                    <label for="graduationYear">Год окончания:</label>
                    <input type="text" id="graduationYear" name="graduationYear" required>

                    <label for="dismissalInfo">Информация об отчислении:</label>
                    <input type="text" id="dismissalInfo" name="dismissalInfo">

                    <label for="dismissalDate">Дата отчисления:</label>
                    <input type="date" id="dismissalDate" name="dismissalDate">

                    <label for="notes">Примечание:</label>
                    <input type="text" id="notes" name="notes">

                    <label for="parentsInfo">Информация о родителях:</label>
                    <input type="text" id="parentsInfo" name="parentsInfo">

                    <label for="penalties">Штрафы:</label>
                    <input type="text" id="penalties" name="penalties">

                    <button type="submit" class="button button-blue">Добавить</button>
                </form>
            </div>

            <!-- Форма для редактирования студента -->
            <div id="editForm" style="display: none;">
                <h3>Редактировать студента</h3>
                <form method="post" action="students.php">
                    <input type="hidden" name="edit_student" value="1">
                    <input type="hidden" id="editStudentID" name="studentID">
                    <label for="editLastName">Фамилия:</label>
                    <input type="text" id="editLastName" name="lastName" required>

                    <label for="editFirstName">Имя:</label>
                    <input type="text" id="editFirstName" name="firstName" required>

                    <label for="editMiddleName">Отчество:</label>
                    <input type="text" id="editMiddleName" name="middleName" required>

                    <label for="editBirthDate">Дата рождения:</label>
                    <input type="date" id="editBirthDate" name="birthDate" required>

                    <label for="editGender">Пол:</label>
                    <input type="text" id="editGender" name="gender" required>

                    <label for="editContactNumber">Контактный номер:</label>
                    <input type="text" id="editContactNumber" name="contactNumber" required>

                    <label for="editEducationLevel">Образование:</label>
                    <input type="text" id="editEducationLevel" name="educationLevel" required>

                    <label for="editDepartment">Отделение:</label>
                    <input type="text" id="editDepartment" name="department" required>

                    <label for="editGroupName">Группа:</label>
                    <input type="text" id="editGroupName" name="groupName" required>

                    <label for="editFundingType">Финансирование:</label>
                    <input type="text" id="editFundingType" name="fundingType" required>

                    <label for="editAdmissionYear">Год поступления:</label>
                    <input type="text" id="editAdmissionYear" name="admissionYear" required>

                    <label for="editGraduationYear">Год окончания:</label>
                    <input type="text" id="editGraduationYear" name="graduationYear" required>

                    <label for="editDismissalInfo">Информация об отчислении:</label>
                    <input type="text" id="editDismissalInfo" name="dismissalInfo">

                    <label for="editDismissalDate">Дата отчисления:</label>
                    <input type="date" id="editDismissalDate" name="dismissalDate">

                    <label for="editNotes">Примечание:</label>
                    <input type="text" id="editNotes" name="notes">

                    <label for="editParentsInfo">Информация о родителях:</label>
                    <input type="text" id="editParentsInfo" name="parentsInfo">

                    <label for="editPenalties">Штрафы:</label>
                    <input type="text" id="editPenalties" name="penalties">

                    <button type="submit" class="button button-blue">Сохранить</button>
                </form>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Фамилия</th>
                        <th>Имя</th>
                        <th>Отчество</th>
                        <th>Дата рождения</th>
                        <th>Пол</th>
                        <th>Контактный номер</th>
                        <th>Образование</th>
                        <th>Отделение</th>
                        <th>Группа</th>
                        <th>Финансирование</th>
                        <th>Год поступления</th>
                        <th>Год окончания</th>
                        <th>Информация об отчислении</th>
                        <th>Дата отчисления</th>
                        <th>Примечание</th>
                        <th>Информация о родителях</th>
                        <th>Штрафы</th>
                        <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                            <th>Действия</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $student): ?>
                        <tr>
                            <td><?php echo $student->lastName; ?></td>
                            <td><?php echo $student->firstName; ?></td>
                            <td><?php echo $student->middleName; ?></td>
                            <td><?php echo $student->birthDate; ?></td>
                            <td><?php echo $student->gender; ?></td>
                            <td><?php echo $student->contactNumber; ?></td>
                            <td><?php echo $student->educationLevel; ?></td>
                            <td><?php echo $student->department; ?></td>
                            <td><?php echo $student->groupName; ?></td>
                            <td><?php echo $student->fundingType; ?></td>
                            <td><?php echo $student->admissionYear; ?></td>
                            <td><?php echo $student->graduationYear; ?></td>
                            <td><?php echo $student->dismissalInfo; ?></td>
                            <td><?php echo $student->dismissalDate; ?></td>
                            <td><?php echo $student->notes; ?></td>
                            <td><?php echo $student->parentsInfo; ?></td>
                            <td><?php echo $student->penalties; ?></td>
                            <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
                                <td>
                                    <button onclick='showEditForm(<?php echo $student->studentID; ?>, "<?php echo $student->lastName; ?>", "<?php echo $student->firstName; ?>", "<?php echo $student->middleName; ?>", "<?php echo $student->birthDate; ?>", "<?php echo $student->gender; ?>", "<?php echo $student->contactNumber; ?>", "<?php echo $student->educationLevel; ?>", "<?php echo $student->department; ?>", "<?php echo $student->groupName; ?>", "<?php echo $student->fundingType; ?>", "<?php echo $student->admissionYear; ?>", "<?php echo $student->graduationYear; ?>", "<?php echo $student->dismissalInfo; ?>", "<?php echo $student->dismissalDate; ?>", "<?php echo $student->notes; ?>", "<?php echo $student->parentsInfo; ?>", "<?php echo $student->penalties; ?>")' class='button button-blue'>Редактировать</button>
                                    <button class='button button-red'><a href='students.php?delete_id=<?php echo $student->studentID; ?>'>Удалить</a></button>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </main>
    <footer>
        <p>&copy; Моисеев и Омельченко, 2025 Информационная система учебного заведения</p>
    </footer>
    <script>
        function showAddForm() {
            document.getElementById('addForm').style.display = 'block';
        }

        function showEditForm(studentID, lastName, firstName, middleName, birthDate, gender, contactNumber, educationLevel, department, groupName, fundingType, admissionYear, graduationYear, dismissalInfo, dismissalDate, notes, parentsInfo, penalties) {
            document.getElementById('editForm').style.display = 'block';
            document.getElementById('editStudentID').value = studentID;
            document.getElementById('editLastName').value = lastName;
            document.getElementById('editFirstName').value = firstName;
            document.getElementById('editMiddleName').value = middleName;
            document.getElementById('editBirthDate').value = birthDate;
            document.getElementById('editGender').value = gender;
            document.getElementById('editContactNumber').value = contactNumber;
            document.getElementById('editEducationLevel').value = educationLevel;
            document.getElementById('editDepartment').value = department;
            document.getElementById('editGroupName').value = groupName;
            document.getElementById('editFundingType').value = fundingType;
            document.getElementById('editAdmissionYear').value = admissionYear;
            document.getElementById('editGraduationYear').value = graduationYear;
            document.getElementById('editDismissalInfo').value = dismissalInfo;
            document.getElementById('editDismissalDate').value = dismissalDate;
            document.getElementById('editNotes').value = notes;
            document.getElementById('editParentsInfo').value = parentsInfo;
            document.getElementById('editPenalties').value = penalties;
        }
    </script>
</body>
</html>
