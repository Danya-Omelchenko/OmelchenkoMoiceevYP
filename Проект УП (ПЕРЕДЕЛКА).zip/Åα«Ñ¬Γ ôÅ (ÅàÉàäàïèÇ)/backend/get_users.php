<?
    include_once("../db_connection.php");
    include_once("../models/StudentManager.php");

    echo $_POST["text"]."123123";

    $student = new Student("1", "2");
    $student->Add();
    //echo json_encode($student);
?>