<?php
class Student {
    public $studentID;
    public $lastName;
    public $firstName;
    public $middleName;
    public $birthDate;
    public $gender;
    public $contactNumber;
    public $educationLevel;
    public $department;
    public $groupName;
    public $fundingType;
    public $admissionYear;
    public $graduationYear;
    public $dismissalInfo;
    public $dismissalDate;
    public $notes;
    public $parentsInfo;
    public $penalties;

    public function __construct($data) {
        $this->studentID = $data['studentID'] ?? null;
        $this->lastName = $data['lastName'] ?? '';
        $this->firstName = $data['firstName'] ?? '';
        $this->middleName = $data['middleName'] ?? '';
        $this->birthDate = $data['birthDate'] ?? '';
        $this->gender = $data['gender'] ?? '';
        $this->contactNumber = $data['contactNumber'] ?? '';
        $this->educationLevel = $data['educationLevel'] ?? '';
        $this->department = $data['department'] ?? '';
        $this->groupName = $data['groupName'] ?? '';
        $this->fundingType = $data['fundingType'] ?? '';
        $this->admissionYear = $data['admissionYear'] ?? '';
        $this->graduationYear = $data['graduationYear'] ?? '';
        $this->dismissalInfo = $data['dismissalInfo'] ?? '';
        $this->dismissalDate = $data['dismissalDate'] ?? '';
        $this->notes = $data['notes'] ?? '';
        $this->parentsInfo = $data['parentsInfo'] ?? '';
        $this->penalties = $data['penalties'] ?? '';
    }
}

class StudentManager {
    private $conn;

    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }

    public function addStudent(Student $student) {
        $query = "INSERT INTO Students (LastName, FirstName, MiddleName, BirthDate, Gender, ContactNumber, EducationLevel, Department, GroupName, FundingType, AdmissionYear, GraduationYear, DismissalInfo, DismissalDate, Notes, ParentsInfo, Penalties)
                  VALUES ('{$student->lastName}', '{$student->firstName}', '{$student->middleName}', '{$student->birthDate}', '{$student->gender}', '{$student->contactNumber}', '{$student->educationLevel}', '{$student->department}', '{$student->groupName}', '{$student->fundingType}', '{$student->admissionYear}', '{$student->graduationYear}', '{$student->dismissalInfo}', '{$student->dismissalDate}', '{$student->notes}', '{$student->parentsInfo}', '{$student->penalties}')";
        return $this->conn->query($query);
    }

    public function editStudent(Student $student) {
        $query = "UPDATE Students SET
                  LastName = '{$student->lastName}',
                  FirstName = '{$student->firstName}',
                  MiddleName = '{$student->middleName}',
                  BirthDate = '{$student->birthDate}',
                  Gender = '{$student->gender}',
                  ContactNumber = '{$student->contactNumber}',
                  EducationLevel = '{$student->educationLevel}',
                  Department = '{$student->department}',
                  GroupName = '{$student->groupName}',
                  FundingType = '{$student->fundingType}',
                  AdmissionYear = '{$student->admissionYear}',
                  GraduationYear = '{$student->graduationYear}',
                  DismissalInfo = '{$student->dismissalInfo}',
                  DismissalDate = '{$student->dismissalDate}',
                  Notes = '{$student->notes}',
                  ParentsInfo = '{$student->parentsInfo}',
                  Penalties = '{$student->penalties}'
                  WHERE StudentID = '{$student->studentID}'";
        return $this->conn->query($query);
    }

    public function deleteStudent($studentID) {
        $this->conn->begin_transaction();

        try {
            $tables = ['DisabledStudents', 'Orphans', 'SpecialNeedsStudents', 'Dormitories', 'RiskGroups', 'SPPPMeetings', 'SVOStatus', 'SocialScholarships'];

            foreach ($tables as $table) {
                $query = "DELETE FROM $table WHERE StudentID = '$studentID'";
                $this->conn->query($query);
            }

            $query = "DELETE FROM Students WHERE StudentID = '$studentID'";
            $this->conn->query($query);

            $this->conn->commit();
        } catch (Exception $e) {
            $this->conn->rollback();
            throw $e;
        }
    }

    public function getStudents() {
        $students = array();
        $query = "SELECT * FROM Students";
        $result = $this->conn->query($query);
        while($row = $result->fetch_assoc()) {
            $students[] = new Student($row);
        }
        return $students;
    }
}
?>
    